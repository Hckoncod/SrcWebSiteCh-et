import { Status } from '@/components/status';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

export default function StatusPage() {
  return (
    <div className="container py-12 md:py-20">
      <div className="mb-12 text-center">
        <h1 className="text-4xl font-bold tracking-tighter font-headline sm:text-5xl md:text-6xl">
          System Status
        </h1>
        <p className="max-w-2xl mx-auto mt-4 text-muted-foreground md:text-xl">
          Live updates on tool detection and system uptime. Your safety is our priority.
        </p>
      </div>

      <div className="max-w-2xl mx-auto">
        <Status />
      </div>

      <div className="mt-12 text-center">
         <Link href="/products">
            <Button size="lg" variant="outline">
                Browse Products
            </Button>
        </Link>
      </div>
    </div>
  );
}
