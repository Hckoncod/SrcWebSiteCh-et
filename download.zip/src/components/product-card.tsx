import Link from 'next/link';
import { Star, ShoppingCart } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { Product } from '@/lib/types';
import { cn } from '@/lib/utils';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <Card className="flex flex-col overflow-hidden transition-all duration-300 ease-in-out bg-card/80 hover:bg-card hover:shadow-lg hover:shadow-primary/20 hover:-translate-y-1 border-border/50 hover:border-primary/30">
      <CardHeader className="relative p-6">
        {product.tags.length > 0 && (
          <div className="absolute top-4 left-4">
            {product.tags.map(tag => (
              <Badge key={tag} variant={tag === 'MOST POPULAR' ? 'default' : 'secondary'} className="bg-primary/80 backdrop-blur-sm text-xs uppercase tracking-wider">
                {tag}
              </Badge>
            ))}
          </div>
        )}
        <div className="text-2xl font-bold text-right text-primary">${product.price.toFixed(2)}</div>
      </CardHeader>
      <CardContent className="p-6 pt-0 flex-grow flex flex-col">
        <CardTitle className="text-xl font-headline">{product.name}</CardTitle>
        <CardDescription className="mt-2 text-muted-foreground flex-grow">{product.description}</CardDescription>
        
        <div className="flex justify-between items-center mt-6">
          <div className="flex items-center gap-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={cn(
                  "h-4 w-4",
                  i < Math.round(product.rating) ? "text-accent fill-accent" : "text-muted-foreground/30"
                )}
              />
            ))}
          </div>
          <p className="text-xs text-muted-foreground">({product.reviewsCount} reviews)</p>
        </div>

        <div className="mt-6">
            <Link href="#" className="w-full">
                <Button className="w-full font-bold" size="lg">
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    Purchase
                </Button>
            </Link>
        </div>
      </CardContent>
    </Card>
  );
}
