"use client";
import Link from "next/link";
import { usePathname } from 'next/navigation';
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import Countdown from "../countdown";
import { Icon } from "../icons";

const navLinks = [
    { name: "Home", href: "/" },
    { name: "Products", href: "/products" },
    { name: "Reviews", href: "/reviews" },
    { name: "Media", href: "#" },
    { name: "Status", href: "/status" },
    { name: "Support", href: "#" },
];

export function SiteHeader() {
  const pathname = usePathname();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="bg-primary text-primary-foreground text-center py-2 px-4 text-sm font-semibold">
        <div className="container flex items-center justify-between">
            <span>Winter Sale – Ending Soon</span>
            <Countdown />
        </div>
      </div>
      <div className="container flex h-16 items-center">
        <div className="mr-4 hidden md:flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <Icon.Logo className="h-6 w-6 text-primary" />
            <span className="hidden font-bold sm:inline-block font-headline text-lg">
              Exploiter Heaven
            </span>
          </Link>
          <nav className="flex items-center space-x-6 text-sm font-medium">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                className={cn(
                  "transition-colors hover:text-foreground/80",
                  pathname === link.href ? "text-foreground" : "text-foreground/60"
                )}
              >
                {link.name}
              </Link>
            ))}
          </nav>
        </div>
        
        <Sheet>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="inline-flex items-center justify-center whitespace-nowrap rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 hover:bg-accent hover:text-accent-foreground h-9 w-9 md:hidden"
            >
              <Menu className="h-6 w-5" />
              <span className="sr-only">Toggle Menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left">
            <Link href="/" className="flex items-center space-x-2">
                <Icon.Logo className="h-6 w-6 text-primary" />
                <span className="font-bold font-headline text-lg">Exploiter Heaven</span>
            </Link>
            <div className="flex flex-col space-y-4 mt-6">
                {navLinks.map((link) => (
                <Link
                    key={link.name}
                    href={link.href}
                    className={cn(
                    "text-lg",
                    pathname === link.href ? "text-foreground" : "text-muted-foreground"
                    )}
                >
                    {link.name}
                </Link>
                ))}
            </div>
          </SheetContent>
        </Sheet>

        <div className="flex flex-1 items-center justify-between space-x-2 md:justify-end">
            <div className="flex items-center gap-2 text-sm font-semibold text-green-400">
                <ShieldCheck className="h-5 w-5 text-green-400" />
                <div className="flex flex-col text-left">
                    <span className="text-xs">Status: Undetected</span>
                    <span className="text-xs text-muted-foreground">Last updated: Today</span>
                </div>
            </div>
        </div>
      </div>
    </header>
  );
}
