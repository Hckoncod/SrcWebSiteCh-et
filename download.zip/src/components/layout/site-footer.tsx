import Link from "next/link";
import { Icon } from "@/components/icons";

const footerLinks = {
    support: [
        { name: "Terms of Service", href: "#" },
        { name: "Support", href: "#" },
        { name: "Discord", href: "#" },
        { name: "Status", href: "/status" },
    ],
    products: [
        { name: "Fortnite Private", href: "/products" },
        { name: "BO7/WZ External", href: "/products" },
        { name: "BO6 External", href: "/products" },
        { name: "Permanent HWID Spoofer", href: "/products" },
        { name: "Roblox", href: "/products" },
    ],
};

export function SiteFooter() {
  return (
    <footer className="border-t">
      <div className="container py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center space-x-2">
                <Icon.Logo className="h-8 w-8 text-primary" />
                <span className="font-bold text-2xl font-headline">Exploiter Heaven</span>
            </Link>
            <p className="mt-4 text-sm text-muted-foreground max-w-xs">
              At Exploiter Heaven, we specialize in developing elite cheats and hacks for a variety of online PC games. Ready to dominate? Get started with Exploiter Heaven today!
            </p>
          </div>
          <div className="grid grid-cols-2 gap-8 md:col-span-3 sm:grid-cols-3">
            <div>
              <h3 className="font-semibold tracking-wider uppercase font-headline">Support & Contact</h3>
              <ul className="mt-4 space-y-2">
                {footerLinks.support.map((link) => (
                  <li key={link.name}>
                    <Link href={link.href} className="text-sm text-muted-foreground hover:text-foreground">
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
                <h3 className="font-semibold tracking-wider uppercase font-headline">Supported Products</h3>
                <ul className="mt-4 space-y-2">
                    {footerLinks.products.map((link) => (
                    <li key={link.name}>
                        <Link href={link.href} className="text-sm text-muted-foreground hover:text-foreground">
                        {link.name}
                        </Link>
                    </li>
                    ))}
                </ul>
            </div>
          </div>
        </div>
        <div className="mt-8 border-t pt-8 flex flex-col md:flex-row items-center justify-between text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Exploiter Heaven. All rights reserved.</p>
          <div className="flex items-center gap-4 mt-4 md:mt-0">
            <Link href="#" className="hover:text-foreground">Terms of Service</Link>
            <Link href="#" className="hover:text-foreground">Support</Link>
            <Link href="/status" className="hover:text-foreground">Status</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
