import { Button } from "@/components/ui/button"
import Link from "next/link"

export function CTA() {
  return (
    <section className="container text-center">
      <div className="bg-card rounded-lg p-8 md:p-12 border border-primary/20 shadow-lg shadow-primary/10">
        <h2 className="text-3xl md:text-4xl font-bold tracking-tighter font-headline">Ready to Join Our Happy Customers?</h2>
        <p className="mt-4 max-w-xl mx-auto text-muted-foreground">
          Experience the same results that our customers are raving about. Elite tools, instant access, and 24/7 human support.
        </p>
        <div className="mt-8">
            <Link href="/products">
                <Button size="lg">
                    Browse Products
                </Button>
            </Link>
        </div>
      </div>
    </section>
  )
}
