import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Status } from '../status';
import { Users, Lock, Zap } from 'lucide-react';

export function HeroSection() {
    const heroImage = PlaceHolderImages.find(p => p.id === 'heroImage');
    return (
        <section className="relative w-full py-20 md:py-32 overflow-hidden">
             {heroImage && (
                <Image
                    src={heroImage.imageUrl}
                    alt="Background"
                    fill
                    className="object-cover object-center opacity-10"
                    priority
                />
            )}
            <div className="container relative z-10">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    <div className="text-center lg:text-left">
                        <h1 className="text-4xl font-bold tracking-tighter text-white sm:text-5xl md:text-6xl lg:text-7xl font-headline">
                            Dominate <span className="text-primary">Every Game</span>
                        </h1>
                        <p className="mt-6 max-w-lg mx-auto lg:mx-0 text-lg text-muted-foreground md:text-xl">
                            Premium Fortnite cheats, HWID spoofers, and BO6 tools. Undetected aimbot, ESP, and instant delivery with 24/7 support.
                        </p>
                        <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                            <Link href="/products">
                                <Button size="lg">Explore Products</Button>
                            </Link>
                            <Link href="#">
                                <Button size="lg" variant="outline">
                                    How We Operate
                                </Button>
                            </Link>
                        </div>
                        <div className="mt-10 flex justify-center lg:justify-start space-x-6 text-sm text-muted-foreground">
                            <div className="flex items-center gap-2">
                                <Lock className="w-4 h-4 text-primary" />
                                <span>Secure</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <Zap className="w-4 h-4 text-primary" />
                                <span>Instant Delivery</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <Users className="w-4 h-4 text-primary" />
                                <span>10,000+ Users</span>
                            </div>
                        </div>
                    </div>
                    <div className="hidden lg:flex justify-center">
                       <Status />
                    </div>
                </div>
            </div>
        </section>
    );
}
