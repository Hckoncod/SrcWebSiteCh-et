import { products } from "@/lib/products"
import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export function FeaturedProducts() {
  const featured = products.filter(p => p.tags.includes('MOST POPULAR') || p.tags.includes('FEATURED')).slice(0, 4)

  return (
    <section className="container">
      <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-10">
        <div>
            <h2 className="text-sm font-semibold uppercase tracking-wider text-primary">Player Favorites</h2>
            <p className="mt-2 text-3xl md:text-4xl font-bold tracking-tighter font-headline">
            Featured Products
            </p>
            <p className="mt-4 max-w-xl text-muted-foreground">
            Hand-picked tools the comp scene can’t stop talking about. Each product ships with instant delivery, live support, and obsessive detection monitoring.
            </p>
        </div>
        <div className="flex-shrink-0">
            <Link href="/products">
                <Button variant="ghost">
                    View All Products
                    <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
            </Link>
        </div>
      </div>
      
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {featured.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  )
}
