import { Zap, ShieldCheck, LifeBuoy, EyeOff, Gauge, ChevronsUp, CreditCard, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';

const features = [
    { icon: ShieldCheck, text: "Fully undetected by anti-cheat systems" },
    { icon: ChevronsUp, text: "Regular updates & new features" },
    { icon: Zap, text: "Instant access after purchase" },
    { icon: LifeBuoy, text: "24/7 Heaven Support" },
    { icon: EyeOff, text: "Stealth Technology" },
    { icon: Gauge, text: "Ultra Fast Performance" },
    { icon: CreditCard, text: "Encrypted Payments" },
    { icon: Settings, text: "Effortless Setup" },
];

export function FeaturesMarquee() {
    const marqueeContent = [...features, ...features]; // Duplicate for seamless loop

    return (
        <div className="relative w-full overflow-hidden bg-primary/5 py-4">
            <div className="absolute inset-0 bg-grid-slate-900/[0.04] bg-[10px_10px]"></div>
            <div className="relative flex animate-marquee-horizontal group-hover:paused">
                {marqueeContent.map((feature, index) => (
                    <div key={index} className="flex-shrink-0 flex items-center gap-3 px-6 mx-4">
                        <feature.icon className="w-5 h-5 text-primary" />
                        <span className="text-sm font-medium text-muted-foreground whitespace-nowrap">{feature.text}</span>
                    </div>
                ))}
            </div>
            <div className="absolute inset-0 pointer-events-none bg-gradient-to-r from-background via-transparent to-background"></div>
        </div>
    );
}
