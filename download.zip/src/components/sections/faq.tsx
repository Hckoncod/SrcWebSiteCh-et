import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

const faqs = [
  {
    question: "Is your cheat undetected?",
    answer: "Yes, our tools are constantly updated to stay ahead of detection systems. We prioritize your safety above all else and have a 99.9% uptime record. Any potential detection leads to an immediate product takedown and update."
  },
  {
    question: "How do I install the cheat?",
    answer: "After purchase, you'll receive immediate access to our loader and a personal key. Our user-friendly instructions allow you to get up and running within minutes - no advanced tech knowledge required. Our support team is also available 24/7 to help."
  },
  {
    question: "Does this work on AMD or Intel?",
    answer: "Our products are compatible with both AMD and Intel processors. We ensure broad compatibility across different hardware setups. For specific requirements, please check the product page."
  },
  {
    question: "Do you offer refunds?",
    answer: "Due to the digital nature of our products, we generally do not offer refunds. However, if you experience technical issues that our support team cannot resolve, we may offer a replacement or store credit on a case-by-case basis."
  }
]

export function Faq() {
  return (
    <section className="container max-w-4xl">
      <div className="text-center mb-10">
        <h2 className="text-sm font-semibold uppercase tracking-wider text-primary">Need-to-know</h2>
        <p className="mt-2 text-3xl md:text-4xl font-bold tracking-tighter font-headline">
          Frequently Asked Questions
        </p>
        <p className="mt-4 max-w-2xl mx-auto text-muted-foreground">
            Quick answers for the things buyers ask our support the most. Open a ticket if you need anything deeper – a real person is online in under 3 minutes.
        </p>
      </div>
      <Accordion type="single" collapsible className="w-full">
        {faqs.map((faq, index) => (
          <AccordionItem key={index} value={`item-${index}`}>
            <AccordionTrigger className="text-lg text-left hover:no-underline">{faq.question}</AccordionTrigger>
            <AccordionContent className="text-base text-muted-foreground">
              {faq.answer}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </section>
  )
}
