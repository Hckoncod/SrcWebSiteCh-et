const steps = [
    {
        step: 1,
        title: "Private, Secure Access",
        description: "All of our tools are kept private and undetected. We do not sell to the public mass market - access is limited and carefully monitored to protect the integrity of our services and our users."
    },
    {
        step: 2,
        title: "Instant Delivery & Easy Setup",
        description: "After purchase, you'll receive immediate access to your loader or key. Our user-friendly instructions allow you to get up and running within minutes - no tech knowledge required."
    },
    {
        step: 3,
        title: "Ongoing Detection Monitoring",
        description: "Our dev team monitors all tools 24/7 to ensure they remain undetected. If any detection is suspected, we immediately pull the product and release updates or fixes. Your safety comes first."
    },
    {
        step: 4,
        title: "Real Support, Real People",
        description: "Whether you're having issues with setup, updates, or need general help, our support team is available via live chat or Discord tickets - fast replies, no bots."
    },
    {
        step: 5,
        title: "Spoofer & Protection Tools Included",
        description: "We offer optional spoofers and hardware protection tools for users who want to stay extra safe from bans or HWID flags."
    },
    {
        step: 6,
        title: "Flexible Plans",
        description: "We offer plans ranging from 1-day trials to full lifetime access. You're in control - upgrade, pause, or renew as needed."
    }
];

export function HowItWorks() {
    return (
        <section className="bg-card py-16 md:py-24">
            <div className="container">
                <div className="text-center mb-12">
                    <h2 className="text-sm font-semibold uppercase tracking-wider text-primary">Operating Principles</h2>
                    <p className="mt-2 text-3xl md:text-4xl font-bold tracking-tighter font-headline">
                        How We Operate
                    </p>
                    <p className="mt-4 max-w-3xl mx-auto text-muted-foreground">
                        We keep Exploiter Heaven lean, secure, and obsessively maintained so every buyer enjoys private access, instant delivery, and real humans watching detections around the clock.
                    </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {steps.map((step) => (
                        <div key={step.step} className="flex gap-6">
                            <div className="flex-shrink-0 text-3xl font-bold font-headline text-primary">
                                {String(step.step).padStart(2, '0')}
                            </div>
                            <div>
                                <h3 className="text-lg font-semibold font-headline">{step.title}</h3>
                                <p className="mt-2 text-muted-foreground">{step.description}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    )
}
