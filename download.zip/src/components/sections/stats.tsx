const stats = [
    { value: "10K+", label: "Active Users" },
    { value: "99.9%", label: "Uptime" },
    { value: "<1min", label: "Delivery Time" },
    { value: "24/7", label: "Support" },
];

export function StatsSection() {
    return (
        <section className="bg-background">
            <div className="container">
                <div className="bg-card rounded-lg border">
                    <div className="grid grid-cols-2 md:grid-cols-4 divide-y md:divide-y-0 md:divide-x">
                        {stats.map((stat, index) => (
                            <div key={index} className="p-6 text-center">
                                <p className="text-3xl md:text-4xl font-bold text-primary font-headline">
                                    {stat.value}
                                </p>
                                <p className="mt-2 text-sm text-muted-foreground uppercase tracking-wider">
                                    {stat.label}
                                </p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
}
