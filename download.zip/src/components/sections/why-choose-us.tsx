import { ShieldCheck, Zap, Users, Gem, Lock, LifeBuoy } from 'lucide-react';

const advantages = [
    {
        icon: ShieldCheck,
        title: "100% Undetectable",
        description: "Our tools are constantly updated to stay ahead of detection systems. We prioritize your safety above all else."
    },
    {
        icon: Zap,
        title: "Lightning Fast Setup",
        description: "Get up and running in minutes, not hours. Our intuitive loaders make installation effortless."
    },
    {
        icon: Users,
        title: "Trusted by Thousands",
        description: "Join thousands of satisfied customers who trust Plasma for their gaming enhancement needs."
    },
    {
        icon: Gem,
        title: "Premium Quality",
        description: "We don't compromise on quality. Every tool is crafted with precision and attention to detail."
    },
    {
        icon: Lock,
        title: "Private & Secure",
        description: "Your privacy is our priority. All transactions and data are encrypted and kept confidential."
    },
    {
        icon: LifeBuoy,
        title: "24/7 Support",
        description: "Our dedicated support team is always ready to help you with any questions or issues."
    }
];

export function WhyChooseUs() {
    return (
        <section className="container">
            <div className="text-center mb-12">
                <h2 className="text-sm font-semibold uppercase tracking-wider text-primary">Why players stay</h2>
                <p className="mt-2 text-3xl md:text-4xl font-bold tracking-tighter font-headline">
                    Why Choose Plasma?
                </p>
                <p className="mt-4 max-w-3xl mx-auto text-muted-foreground">
                    Everything we ship is battle-tested with competitive players, monitored by devs, and backed by humans who actually play the games.
                </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {advantages.map((advantage, index) => (
                    <div key={index} className="flex flex-col items-center text-center p-6 rounded-lg bg-card transition-all hover:bg-primary/10">
                        <div className="bg-primary/20 text-primary rounded-full p-3 mb-4">
                            <advantage.icon className="w-6 h-6" />
                        </div>
                        <h3 className="text-lg font-semibold font-headline">{advantage.title}</h3>
                        <p className="mt-2 text-sm text-muted-foreground">{advantage.description}</p>
                    </div>
                ))}
            </div>
            <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-8 text-center">
                <div className="bg-card p-6 rounded-lg">
                    <p className="text-4xl font-bold font-headline text-primary">10,000+</p>
                    <p className="mt-1 text-muted-foreground">Happy Customers</p>
                </div>
                <div className="bg-card p-6 rounded-lg">
                    <p className="text-4xl font-bold font-headline text-primary">99.9%</p>
                    <p className="mt-1 text-muted-foreground">Uptime Guarantee</p>
                </div>
                <div className="bg-card p-6 rounded-lg">
                    <p className="text-4xl font-bold font-headline text-primary">24/7</p>
                    <p className="mt-1 text-muted-foreground">Human Support</p>
                </div>
            </div>
        </section>
    );
}
